#### Watch

```bash
sass --watch style.scss:style.css --debug-info
```